extends Sprite2D

@onready var anim_player: AnimationPlayer = $Purge_Animation

func _ready() -> void:
	visible = false
	add_to_group("PurgeVFX")

func tocar_efeito(posicao_alvo: Vector2) -> void:
	global_position = posicao_alvo
	visible = true
	anim_player.play("Purge")
	
	await anim_player.animation_finished
	visible = false
