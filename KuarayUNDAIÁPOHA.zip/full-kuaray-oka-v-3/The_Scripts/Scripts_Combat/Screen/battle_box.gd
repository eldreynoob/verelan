extends Panel

@onready var top_wall: CollisionShape2D = $CollideBox/Up
@onready var bottom_wall: CollisionShape2D = $CollideBox/Down
@onready var left_wall: CollisionShape2D = $CollideBox/Left
@onready var right_wall: CollisionShape2D = $CollideBox/Right
@onready var circle_accuracy: TextureButton = $CircleAccuracy

var menu_size: Vector2
var menu_pos: Vector2
var combat_size: Vector2
var combat_pos: Vector2

const WALL_THICKNESS: float = 20.0

func _ready() -> void:
	menu_size = size
	menu_pos = position
	combat_size = Vector2(size.y, size.y)
	combat_pos = Vector2(position.x + (size.x - combat_size.x) / 2.0, position.y)
	
	resized.connect(_update_collisions)
	_update_collisions()

func virar_quadrado() -> void:
	var tween = create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween.set_parallel(true)
	tween.tween_property(self, "size", combat_size, 0.4)
	tween.tween_property(self, "position", combat_pos, 0.4)
	await tween.finished

func virar_retangulo() -> void:
	var tween = create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween.set_parallel(true)
	tween.tween_property(self, "size", menu_size, 0.4)
	tween.tween_property(self, "position", menu_pos, 0.4)
	await tween.finished

func _update_collisions() -> void:
	if not top_wall or not top_wall.shape: return
	var box_size = size
	const BORDER_THICKNESS: float = 10.0 
	
	(top_wall.shape as RectangleShape2D).size = Vector2(box_size.x, WALL_THICKNESS)
	top_wall.position = Vector2(box_size.x / 2.0, BORDER_THICKNESS - (WALL_THICKNESS / 2.0))
	
	(bottom_wall.shape as RectangleShape2D).size = Vector2(box_size.x, WALL_THICKNESS)
	bottom_wall.position = Vector2(box_size.x / 2.0, box_size.y - BORDER_THICKNESS + (WALL_THICKNESS / 2.0))
	
	(left_wall.shape as RectangleShape2D).size = Vector2(WALL_THICKNESS, box_size.y)
	left_wall.position = Vector2(BORDER_THICKNESS - (WALL_THICKNESS / 2.0), box_size.y / 2.0)
	
	(right_wall.shape as RectangleShape2D).size = Vector2(WALL_THICKNESS, box_size.y)
	right_wall.position = Vector2(box_size.x - BORDER_THICKNESS + (WALL_THICKNESS / 2.0), box_size.y / 2.0)

# ==============================================================================
# MINIGAME DE ATAQUE (ENQUADRAMENTO LOCAL DIRETO NO PANEL)
# ==============================================================================

func executar_minigame_ataque(dano_base: float = 20.0) -> float:
	if not is_node_ready():
		await ready
		
	if not circle_accuracy:
		print("ERRO GRAVE: O nó 'CircleAccuracy' não foi encontrado!")
		return dano_base

	var acertos: int = 0
	
	# Reseta as âncoras para garantir alinhamento local no canto superior esquerdo
	circle_accuracy.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	
	# Obtém as dimensões reais da imagem do alvo
	var tamanho_alvo = Vector2(64, 64)
	if circle_accuracy.texture_normal:
		tamanho_alvo = circle_accuracy.texture_normal.get_size()

	# Margem de segurança para manter o círculo afastado das bordas brancas (15px)
	var margem = 15.0

	# Limites LOCAIS dentro da caixa atual (funciona tanto para retângulo como para quadrado)
	var min_x = margem
	var max_x = maxf(min_x, size.x - margem - tamanho_alvo.x)
	var min_y = margem
	var max_y = maxf(min_y, size.y - margem - tamanho_alvo.y)

	# Exige uma distância mínima de 30% da largura atual da caixa entre spawns
	var distancia_minima = maxf(100.0, size.x * 0.30)
	var posicoes_anteriores: Array[Vector2] = []

	# Loop dos 3 alvos
	for i in range(3):
		var pos_sorteada := Vector2.ZERO
		var encontrou_posicao := false
		
		# Sorteia pontos em toda a largura/altura da caixa
		for tentativa in range(100):
			var candidata = Vector2(
				randf_range(min_x, max_x),
				randf_range(min_y, max_y)
			)
			
			if posicoes_anteriores.is_empty():
				pos_sorteada = candidata
				encontrou_posicao = true
				break
			
			var distancia_ok = true
			for pos_ant in posicoes_anteriores:
				if candidata.distance_to(pos_ant) < distancia_minima:
					distancia_ok = false
					break
			
			if distancia_ok:
				pos_sorteada = candidata
				encontrou_posicao = true
				break
		
		if not encontrou_posicao:
			pos_sorteada = Vector2(randf_range(min_x, max_x), randf_range(min_y, max_y))

		posicoes_anteriores.append(pos_sorteada)
		
		# Atribui a posição LOCAL em relação ao Panel pai
		circle_accuracy.position = pos_sorteada
		
		var acertou: bool = await circle_accuracy.iniciar_tentativa(pos_sorteada)
		
		if acertou:
			acertos += 1
			
		await get_tree().create_timer(0.15).timeout

	# --------------------------------------------------------------------------
	# CÁLCULO DE DANO
	# --------------------------------------------------------------------------
	var multiplicador: float = 0.3
	match acertos:
		3: multiplicador = 1.0
		2: multiplicador = 0.7
		1: multiplicador = 0.5
		0: multiplicador = 0.3
		
	var dano_final = dano_base * multiplicador
	get_tree().call_group("AccuracyLabel", "exibir_precisao", acertos, 3)

	return dano_final
