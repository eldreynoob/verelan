extends Sprite2D

@onready var anim_player: AnimationPlayer = $Spark_Animation

func _ready() -> void:
	visible = false
	add_to_group("SparkVFX")

func tocar_efeito(posicao_alvo: Vector2) -> void:
	# Leve variação para o efeito não surgir sempre exatamente no mesmo pixel
	var offset = Vector2(randf_range(-10, 10), randf_range(-10, 10))
	global_position = posicao_alvo + offset
	
	visible = true
	anim_player.play("Spark")
	
	await anim_player.animation_finished
	visible = false
