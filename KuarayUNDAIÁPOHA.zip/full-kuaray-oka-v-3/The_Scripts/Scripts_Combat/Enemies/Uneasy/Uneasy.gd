extends CharacterBody2D

# ==============================================================================
# 1. REFERÊNCIAS AOS NÓS DA CENA
# ==============================================================================
@onready var sprite: Sprite2D = $Sprite_Uneasy
@onready var anim_player: AnimationPlayer = $Uneasy_Animation
@onready var hitbox = $Hitbox_Uneasy

# Referência flexível para a ProgressBar (pode ser configurada no Inspetor)
@export var progress_bar: ProgressBar

# ==============================================================================
# 2. CONFIGURAÇÕES E ESTADO DO BOSS
# ==============================================================================
@export var hp_maxima: float = 100.0
var hp_atual: float

# ==============================================================================
# 3. INICIALIZAÇÃO
# ==============================================================================
func _ready() -> void:
	hp_atual = hp_maxima
	add_to_group("Enemies")
	
	# Se a ProgressBar não foi atribuída no Inspetor, busca automaticamente na árvore
	if not progress_bar and has_node("ProgressBar"):
		progress_bar = $ProgressBar
		
	if progress_bar:
		progress_bar.max_value = hp_maxima
		progress_bar.value = hp_atual

	# Inicia a animação padrão do Uneasy se existir
	if anim_player and anim_player.has_animation("idle"):
		anim_player.play("idle")

# ==============================================================================
# 4. SISTEMA DE DANO E DERROTA
# ==============================================================================
func receber_dano(quantidade: float) -> void:
	hp_atual = max(0.0, hp_atual - quantidade)
	
	# 1. Dispara o efeito visual de impacto (Spark)
	var spark = get_tree().get_first_node_in_group("SparkVFX")
	if spark and spark.has_method("tocar_efeito"):
		spark.tocar_efeito(global_position)
	
	# 2. Anima a diminuição da vida na ProgressBar
	if progress_bar:
		var tween = create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
		tween.tween_property(progress_bar, "value", hp_atual, 0.4)
	
	# 3. Exibe o pop-up com o valor do dano
	var damage_pop = get_tree().get_first_node_in_group("DamageNumber")
	if damage_pop and damage_pop.has_method("exibir_dano"):
		damage_pop.exibir_dano(quantidade, global_position)
		
	# 4. Checa condição de derrota
	if hp_atual <= 0.0:
		_derrotado()

func _derrotado() -> void:
	print("Uneasy foi derrotado!")
	
	# Desativa a hitbox/colisão para evitar tomar/dar dano pós-morte
	if hitbox:
		hitbox.set_deferred("disabled", true)
		
	if progress_bar:
		progress_bar.visible = false
		
	# Esconde suavemente o Sprite_Uneasy enquanto aciona o Purge
	var tween = create_tween()
	tween.tween_property(sprite, "modulate:a", 0.0, 0.3)
	
	var purge = get_tree().get_first_node_in_group("PurgeVFX")
	if purge and purge.has_method("tocar_efeito"):
		await purge.tocar_efeito(global_position)
	
	queue_free()

# ==============================================================================
# 5. SISTEMA DE ATAQUES DO UNEASY
# ==============================================================================
func iniciar_ataque() -> void:
	# Lógica dos novos ataques do Uneasy
	pass
