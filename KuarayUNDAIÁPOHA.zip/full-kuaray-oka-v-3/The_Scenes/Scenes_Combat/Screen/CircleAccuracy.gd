extends TextureButton

@export var tempo_limite: float = 1.2

var _clicou: bool = false

func _ready() -> void:
	visible = false
	focus_mode = FOCUS_NONE

func iniciar_tentativa(pos_sorteada: Vector2) -> bool:
	# Garante NUNCA ser 0 (se no Inspetor estiver 0, força 1.2 segundos)
	var tempo_real: float = maxf(tempo_limite, 1.0)
	
	position = pos_sorteada
	modulate.a = 1.0
	_clicou = false
	visible = true

	# 1. Trava se o jogador ainda estiver segurando o clique do botão FIGHT
	while Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		await get_tree().process_frame

	# 2. Animação de opacidade esmaecendo
	var tween = create_tween()
	tween.tween_property(self, "modulate:a", 0.2, tempo_real)

	# 3. Contagem regressiva segura por tempo real
	var tempo_decorrido: float = 0.0
	while tempo_decorrido < tempo_real and not _clicou:
		await get_tree().process_frame
		tempo_decorrido += get_process_delta_time()

	# Cancela animação e oculta
	if tween and tween.is_running():
		tween.kill()

	visible = false
	return _clicou

# Captura o clique direto na imagem do alvo
func _gui_input(event: InputEvent) -> void:
	if not visible or _clicou:
		return
		
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_clicou = true
