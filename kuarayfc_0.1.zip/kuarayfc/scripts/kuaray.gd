extends CharacterBody2D

@export var velocidade: float = 150.0

# Referências
@onready var sprite: Sprite2D = $Sprite2D
@onready var anim: AnimationPlayer = $AnimationPlayer

# Referências da UI (CanvasLayer)
@onready var label_dica: Label = $CanvasLayer/UI/Label
@onready var painel_item: Panel = $CanvasLayer/UI/Panel
@onready var item_icone: TextureRect = $CanvasLayer/UI/Panel/TextureRect
@onready var item_titulo: Label = $CanvasLayer/UI/Panel/Label
@onready var item_descricao: Label = $CanvasLayer/UI/Panel/Label2
@onready var botao_fechar: Button = $CanvasLayer/UI/Panel/Button

var painel_aberto: bool = false

func _ready() -> void:
	add_to_group("player")
	
	# Esconde os elementos visuais da UI ao iniciar
	label_dica.visible = false
	painel_item.visible = false
	
	if botao_fechar:
		botao_fechar.pressed.connect(fechar_painel_item)

func _physics_process(_delta: float) -> void:
	# Trava o movimento enquanto o painel estiver aberto
	if painel_aberto:
		velocity = Vector2.ZERO
		tocar_animacao(Vector2.ZERO)
		return

	# Movimento do Player
	var direcao: Vector2 = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	velocity = direcao * velocidade
	move_and_slide()

	tocar_animacao(direcao)

func _unhandled_input(event: InputEvent) -> void:
	# Se o painel estiver aberto, apertar 'E' ou 'Esc' fecha a janela sem conflitos
	if painel_aberto and (event.is_action_pressed("interagir") or event.is_action_pressed("ui_cancel")):
		fechar_painel_item()
		get_viewport().set_input_as_handled()

func tocar_animacao(direcao: Vector2) -> void:
	if direcao.x < 0:
		sprite.flip_h = true
	elif direcao.x > 0:
		sprite.flip_h = false

	if direcao != Vector2.ZERO:
		anim.play("andar")
	else:
		anim.play("parado")

# --- FUNÇÕES DE UI ---

# Nome alinhado com o script da Area2D
func exibir_dica_interacao(texto: String = "Pressione 'E' para interagir") -> void:
	label_dica.text = texto
	label_dica.visible = true

func esconder_dica_interacao() -> void:
	label_dica.visible = false

func exibir_painel_item(titulo: String, descricao: String, icone: Texture2D) -> void:
	item_titulo.text = titulo
	item_descricao.text = descricao
	item_icone.texture = icone
	painel_item.visible = true
	painel_aberto = true

func fechar_painel_item() -> void:
	painel_item.visible = false
	painel_aberto = false
