extends Label

var tween_pop: Tween
var tween_movimento: Tween
var tween_fade: Tween

func _ready() -> void:
	visible = false
	z_index = 100
	add_to_group("DamageNumber")

func exibir_dano(valor_dano: float, pos_global_origem: Vector2) -> void:
	# Cancela animações anteriores se houver hits múltiplos rápidos
	if tween_pop: tween_pop.kill()
	if tween_movimento: tween_movimento.kill()
	if tween_fade: tween_fade.kill()
	
	text = str(round(valor_dano))
	
	# Origem do número no centro do Boss
	global_position = pos_global_origem + Vector2(randf_range(-10.0, 10.0), randf_range(-10.0, 10.0))
	
	pivot_offset = size / 2.0
	modulate.a = 0.0
	scale = Vector2(0.3, 0.3)
	visible = true
	
	# --------------------------------------------------------------------------
	# CÁLCULO DE TRAJETÓRIA E TELA
	# --------------------------------------------------------------------------
	var direcao = -1 if randf() < 0.5 else 1
	var deslocamento_x = randf_range(80.0, 140.0) * direcao
	
	# Pulo inicial para cima
	var altura_pulo = global_position.y - randf_range(70.0, 110.0)
	
	# Borda inferior da tela (rodapé)
	var limite_inferior_tela = get_viewport_rect().size.y - size.y
	
	# Tempos da animação
	var tempo_subida: float = 0.25
	# Ajusta o tempo de queda proporcionalmente à distância até a base da tela
	var distancia_queda = limite_inferior_tela - altura_pulo
	var tempo_queda: float = clamp(distancia_queda / 450.0, 0.6, 1.2)
	var tempo_total: float = tempo_subida + tempo_queda
	
	# --------------------------------------------------------------------------
	# ANIMAÇÕES
	# --------------------------------------------------------------------------
	# 1. Pop de Escala Inicial
	tween_pop = create_tween().set_parallel(true)
	tween_pop.tween_property(self, "modulate:a", 1.0, 0.08)
	tween_pop.tween_property(self, "scale", Vector2(1.5, 1.5), 0.12).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tween_pop.chain().tween_property(self, "scale", Vector2(1.0, 1.0), 0.10)
	
	# 2. Movimento Vertical (Pula e cai até o limite da tela)
	tween_movimento = create_tween()
	tween_movimento.tween_property(self, "global_position:y", altura_pulo, tempo_subida).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tween_movimento.tween_property(self, "global_position:y", limite_inferior_tela, tempo_queda).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	
	# 3. Lançamento Horizontal
	create_tween().tween_property(self, "global_position:x", global_position.x + deslocamento_x, tempo_total).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	
	# 4. Fade-Out Gradual (Inicia após a subida e dura até tocar a base da tela)
	tween_fade = create_tween()
	tween_fade.tween_interval(tempo_subida)
	tween_fade.tween_property(self, "modulate:a", 0.0, tempo_queda).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	
	await tween_movimento.finished
	visible = false
