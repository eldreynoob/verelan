extends TextureProgressBar

func _ready() -> void:
	# Garante a inserção no grupo caso não tenha sido configurado no Inspetor
	if not is_in_group("LifeBarPlayer"):
		add_to_group("LifeBarPlayer")

# Define a vida máxima e inicial
func configurar_vida_maxima(max_hp: float, hp_atual: float) -> void:
	max_value = max_hp
	value = hp_atual

# Atualiza a vida com animação suave de transição (Tween)
func atualizar_vida(nova_hp: float) -> void:
	var tween = create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tween.tween_property(self, "value", nova_hp, 0.3)
