extends Label

var tween_anim: Tween

func _ready() -> void:
	visible = false
	if not is_in_group("AccuracyLabel"):
		add_to_group("AccuracyLabel")

# Chama esta função passando a quantidade acertada e o total de quadrados
func exibir_precisao(quadrados_acertados: int, total_quadrados: int) -> void:
	if total_quadrados <= 0: return
	
	var porcentagem = (float(quadrados_acertados) / float(total_quadrados)) * 100.0
	exibir_porcentagem_direta(porcentagem)

# Ou chama diretamente com o valor da porcentagem (ex: 85.0)
func exibir_porcentagem_direta(porcentagem: float) -> void:
	if tween_anim: tween_anim.kill()
	
	text = str(snapped(porcentagem, 0.1)) + "%"
	
	# Cor dinâmica: Dourado para 100%, Verde para alto acerto, Branco para o resto
	if porcentagem >= 100.0:
		modulate = Color(1, 0.84, 0) # Dourado
	elif porcentagem >= 70.0:
		modulate = Color(0.2, 1.0, 0.3) # Verde
	else:
		modulate = Color(1, 1, 1) # Branco
		
	pivot_offset = size / 2.0
	scale = Vector2(0.4, 0.4)
	modulate.a = 0.0
	visible = true
	
	# Animação de entrada (Surgimento na esquerda com Pop)
	tween_anim = create_tween()
	
	var tween_in = create_tween().set_parallel(true)
	tween_in.tween_property(self, "modulate:a", 1.0, 0.15)
	tween_in.tween_property(self, "scale", Vector2(1.3, 1.3), 0.15).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	
	create_tween().tween_property(self, "scale", Vector2(1.0, 1.0), 0.1)
	
	# Mantém visível durante o ataque/resultado
	await get_tree().create_timer(1.2).timeout
	
	# Fade-Out de saída
	var tween_out = create_tween().set_parallel(true)
	tween_out.tween_property(self, "modulate:a", 0.0, 0.35)
	tween_out.tween_property(self, "scale", Vector2(0.7, 0.7), 0.35)
	
	await tween_out.finished
	visible = false
