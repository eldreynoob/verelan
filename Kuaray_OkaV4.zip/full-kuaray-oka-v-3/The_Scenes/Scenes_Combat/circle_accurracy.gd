extends Button

signal finalizado(sucesso: bool)

@export var tempo_limite: float = 1.0
var ja_respondeu: bool = false
var tentativa_atual: int = 0  # Contador para invalidar timers antigos
var tween_esmaecer: Tween

func _ready() -> void:
	visible = false
	focus_mode = FOCUS_NONE
	mouse_filter = MOUSE_FILTER_STOP

func iniciar_tentativa(pos_sorteada: Vector2) -> bool:
	# Incrementa o número da tentativa para "cancelar" temporizadores anteriores
	tentativa_atual += 1
	var id_local = tentativa_atual
	
	position = pos_sorteada
	visible = true
	ja_respondeu = false
	modulate.a = 1.0

	# Animação esmaecendo durante o tempo de clique
	if tween_esmaecer: tween_esmaecer.kill()
	tween_esmaecer = create_tween()
	tween_esmaecer.tween_property(self, "modulate:a", 0.2, tempo_limite)

	# Cria o timer passando o ID desta tentativa específica
	get_tree().create_timer(tempo_limite).timeout.connect(
		func(): _on_tempo_esgotado(id_local)
	)

	# Aguarda a resposta (clique ou timeout)
	var acertou = await self.finalizado
	visible = false
	return acertou

func _gui_input(event: InputEvent) -> void:
	if ja_respondeu or not visible: return
	
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		ja_respondeu = true
		if tween_esmaecer: tween_esmaecer.kill()
		finalizado.emit(true)

func _on_tempo_esgotado(id_tentativa: int) -> void:
	# Se este temporizador for de uma tentativa antiga, ignora completamente!
	if id_tentativa != tentativa_atual: 
		return
		
	if ja_respondeu or not visible: 
		return
		
	ja_respondeu = true
	if tween_esmaecer: tween_esmaecer.kill()
	finalizado.emit(false)
