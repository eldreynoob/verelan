extends Panel

@onready var top_wall: CollisionShape2D = $CollideBox/Up
@onready var bottom_wall: CollisionShape2D = $CollideBox/Down
@onready var left_wall: CollisionShape2D = $CollideBox/Left
@onready var right_wall: CollisionShape2D = $CollideBox/Right
@onready var circle_accuracy: Button = $CircleAccurracy

var menu_size: Vector2
var menu_pos: Vector2
var combat_size: Vector2
var combat_pos: Vector2

const WALL_THICKNESS: float = 20.0

func _ready() -> void:
	menu_size = size
	menu_pos = position
	combat_size = Vector2(size.y, size.y)
	combat_pos = Vector2(position.x + (size.x - combat_size.x) / 2.0, position.y)
	
	resized.connect(_update_collisions)
	_update_collisions()

func virar_quadrado() -> void:
	var tween = create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween.set_parallel(true)
	tween.tween_property(self, "size", combat_size, 0.4)
	tween.tween_property(self, "position", combat_pos, 0.4)
	await tween.finished

func virar_retangulo() -> void:
	var tween = create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween.set_parallel(true)
	tween.tween_property(self, "size", menu_size, 0.4)
	tween.tween_property(self, "position", menu_pos, 0.4)
	await tween.finished

func _update_collisions() -> void:
	if not top_wall or not top_wall.shape: return
	var box_size = size
	const BORDER_THICKNESS: float = 10.0 
	
	(top_wall.shape as RectangleShape2D).size = Vector2(box_size.x, WALL_THICKNESS)
	top_wall.position = Vector2(box_size.x / 2.0, BORDER_THICKNESS - (WALL_THICKNESS / 2.0))
	
	(bottom_wall.shape as RectangleShape2D).size = Vector2(box_size.x, WALL_THICKNESS)
	bottom_wall.position = Vector2(box_size.x / 2.0, box_size.y - BORDER_THICKNESS + (WALL_THICKNESS / 2.0))
	
	(left_wall.shape as RectangleShape2D).size = Vector2(WALL_THICKNESS, box_size.y)
	left_wall.position = Vector2(BORDER_THICKNESS - (WALL_THICKNESS / 2.0), box_size.y / 2.0)
	
	(right_wall.shape as RectangleShape2D).size = Vector2(WALL_THICKNESS, box_size.y)
	right_wall.position = Vector2(box_size.x - BORDER_THICKNESS + (WALL_THICKNESS / 2.0), box_size.y / 2.0)

# ==============================================================================
# MINIGAME DE ATAQUE (3 ALVOS CLICKÁVEIS)
# ==============================================================================

func executar_minigame_ataque(dano_base: float = 20.0) -> float:
	var acertos: int = 0
	var tamanho_alvo = circle_accuracy.size
	
	# Loop dos 3 alvos
	for i in range(3):
		# Sorteia a posição dentro das margens da caixa
		var margem = 20.0
		var pos_x = randf_range(margem, size.x - tamanho_alvo.x - margem)
		var pos_y = randf_range(margem, size.y - tamanho_alvo.y - margem)
		
		# Chama o nó filho existente para a rodada atual
		var acertou: bool = await circle_accuracy.iniciar_tentativa(Vector2(pos_x, pos_y))
		
		if acertou:
			acertos += 1
			print("Alvo ", i + 1, " -> ACERTOU!")
		else:
			print("Alvo ", i + 1, " -> ERROU!")
			
		# Intervalo de respiro entre um alvo e outro
		await get_tree().create_timer(0.15).timeout

	# --------------------------------------------------------------------------
	# CÁLCULO FINAL DA PRECISÃO E DANO (APÓS CONCLUIR OS 3 ALVOS)
	# --------------------------------------------------------------------------
	var multiplicador: float = 0.3
	match acertos:
		3: multiplicador = 1.0 # 100%
		2: multiplicador = 0.7 # 70%
		1: multiplicador = 0.5 # 50%
		0: multiplicador = 0.3 # 30%
		
	var dano_final = dano_base * multiplicador
	print("Resultado: ", acertos, "/3 acertos | Dano Aplicado: ", dano_final)
	
	# OPÇÃO 1: Exibe a precisão baseada nos acertos reais (ex: 3/3 = 100%, 2/3 = 66.7%, etc.)
	get_tree().call_group("AccuracyLabel", "exibir_precisao", acertos, 3)
	
	# OPÇÃO 2 (Alternativa): Se preferir exibir a porcentagem do multiplicador de dano (100%, 70%, 50%, 30%):
	# get_tree().call_group("AccuracyLabel", "exibir_porcentagem_direta", multiplicador * 100.0)

	return dano_final
