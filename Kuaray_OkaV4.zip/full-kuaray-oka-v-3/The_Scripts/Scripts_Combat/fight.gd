extends Button

@export var dano_base_player: float = 20.0
var esta_em_turno: bool = false

func _on_pressed() -> void:
	if esta_em_turno:
		return
		
	esta_em_turno = true
	
	var kuaray = get_tree().get_first_node_in_group("Player")
	var battle_box = get_tree().get_first_node_in_group("BattleBox")
	var inimigo = get_tree().get_first_node_in_group("Enemies")
	
	# --------------------------------------------------------------------------
	# FASE 1: TURNO DE ATAQUE DO JOGADOR (Caixa Retangular Padrão)
	# --------------------------------------------------------------------------
	var dano_causado: float = 0.0
	if battle_box and battle_box.has_method("executar_minigame_ataque"):
		dano_causado = await battle_box.executar_minigame_ataque(dano_base_player)
	
	# Aplica dano ao Blobl
	if inimigo and inimigo.has_method("receber_dano"):
		inimigo.receber_dano(dano_causado)
		
	# --------------------------------------------------------------------------
	# FASE 2: TURNO DE DEFESA DO JOGADOR (Se o Boss ainda estiver vivo)
	# --------------------------------------------------------------------------
	var boss_vivo = is_instance_valid(inimigo) and inimigo.hp_atual > 0
	
	if boss_vivo:
		# 1. Transforma a caixa em Quadrado
		if battle_box and battle_box.has_method("virar_quadrado"):
			await battle_box.virar_quadrado()
			
		# 2. Ativa o Player no centro da caixa para esquiva
		if kuaray:
			kuaray.visible = true
			kuaray.position = Vector2(576, 380)
			if kuaray.has_method("start_dodging"):
				kuaray.start_dodging()
				
		# 3. Executa e aguarda o ataque completo do Blobl terminar
		if inimigo and inimigo.has_method("iniciar_ataque"):
			await inimigo.iniciar_ataque()
			
		# 4. Oculta o Player ao final da esquiva
		if kuaray:
			kuaray.visible = false
			if kuaray.has_method("stop_dodging"):
				kuaray.stop_dodging()
				
		# 5. Retorna a caixa para o formato Retangular de Menu
		if battle_box and battle_box.has_method("virar_retangulo"):
			await battle_box.virar_retangulo()
			
	esta_em_turno = false
