extends CharacterBody2D

const Tapa_Cena = preload("res://The_Scenes/Scenes_Combat/Blobl/slap.tscn")
const Lambida_Cena = preload("res://The_Scenes/Scenes_Combat/Blobl/Lick.tscn")

# ==============================================================================
# SISTEMA DE VIDA DO BOSS E PROGRESS BAR
# ==============================================================================
@export var hp_maxima: float = 100.0
var hp_atual: float

# Referência à ProgressBar que é filha direta do nó Blobl
@onready var progress_bar: ProgressBar = $ProgressBar

func _ready() -> void:
	hp_atual = hp_maxima
	add_to_group("Enemies") # Garante que o Blobl está registrado no grupo Enemies
	
	# Configura a barra no início com os valores de vida do Boss
	if progress_bar:
		progress_bar.max_value = hp_maxima
		progress_bar.value = hp_atual

func receber_dano(quantidade: float) -> void:
	hp_atual = max(0.0, hp_atual - quantidade)
	
	# 1. Anima a diminuição da vida suavemente na ProgressBar
	if progress_bar:
		var tween = create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
		tween.tween_property(progress_bar, "value", hp_atual, 0.4)
	
	# 2. Busca o nó DamageNumber único na cena e exibe o dano
	var damage_pop = get_tree().get_first_node_in_group("DamageNumber")
	if damage_pop and damage_pop.has_method("exibir_dano"):
		damage_pop.exibir_dano(quantidade, global_position)
		
	# 3. Verifica se a vida zerou para derrotar o boss
	if hp_atual <= 0.0:
		_derrotado()

func _derrotado() -> void:
	print("Blobl foi derrotado!")
	# Animação suave de sumiço antes de deletar o nó
	var tween = create_tween()
	tween.tween_property(self, "modulate:a", 0.0, 0.6)
	await tween.finished
	queue_free()

# ==============================================================================
# ATAQUES DO BLOBL
# ==============================================================================
func iniciar_ataque() -> void:
	var escolha = randi() % 2
	
	if escolha == 0:
		await _sequencia_de_tapas()
	else:
		await _sequencia_de_lambidas()

# --- SISTEMA DE TAPAS ---
func _sequencia_de_tapas() -> void:
	var player = get_tree().get_first_node_in_group("Player")
	var quantidade_tapas = randi_range(15, 25)
	
	for i in range(quantidade_tapas):
		if player:
			_invocar_maozada(player.global_position)
		else:
			_invocar_maozada(Vector2(576, 380))
			
		await get_tree().create_timer(0.4).timeout

func _invocar_maozada(posicao_alvo: Vector2) -> void:
	var novo_tapa = Tapa_Cena.instantiate()
	novo_tapa.global_position = posicao_alvo
	get_tree().current_scene.add_child(novo_tapa)
	
# --- SISTEMA DE LAMBIDAS ---
func _sequencia_de_lambidas() -> void:
	var ondas_de_ataque = randi_range(5, 7)
	
	for i in range(ondas_de_ataque):
		var quantidade_simultanea = randi_range(1, 2)
		
		for j in range(quantidade_simultanea):
			_invocar_lambida_aleatoria()
			
		await get_tree().create_timer(1.2).timeout 

func _invocar_lambida_aleatoria() -> void:
	var nova_lambida = Lambida_Cena.instantiate()
	
	var centro_caixa = Vector2(576, 380)
	var angulo_aleatorio = randf_range(0, TAU)
	var distancia = 250.0 
	
	var pos_spawn = centro_caixa + Vector2(cos(angulo_aleatorio), sin(angulo_aleatorio)) * distancia
	nova_lambida.global_position = pos_spawn
	
	var alvo_aleatorio = centro_caixa + Vector2(randf_range(-80, 80), randf_range(-80, 80))
	nova_lambida.rotation = (alvo_aleatorio - pos_spawn).angle() - PI/2
	
	get_tree().current_scene.add_child(nova_lambida)
