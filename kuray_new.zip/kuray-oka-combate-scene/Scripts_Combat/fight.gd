extends Button

func _ready() -> void:
	pass

func _on_pressed() -> void:
	var kuaray = get_tree().get_first_node_in_group("Player")
	var battle_box = get_tree().get_first_node_in_group("BattleBox")
	
	# Chama o jogador
	if kuaray and kuaray.has_method("start_dodging"):
		kuaray.start_dodging()
		
	# Chama a animação da caixa
	if battle_box and battle_box.has_method("virar_quadrado"):
		battle_box.virar_quadrado()
