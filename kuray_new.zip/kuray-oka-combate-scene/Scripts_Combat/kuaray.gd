extends CharacterBody2D

const SPEED = 200.0

@onready var animation_player: AnimationPlayer = $Kuaray_Animation
@onready var collision_shape: CollisionShape2D = $Kuaray_HitBox # Certifique-se de que o nome da sua colisão é este

func _ready() -> void:
	animation_player.play("Shine")
	stop_dodging()

# Modo de desvio (Aparece e ganha movimento/colisão)
func start_dodging() -> void:
	visible = true
	set_physics_process(true)
	if collision_shape:
		collision_shape.set_deferred("disabled", false) # Jeito seguro de ativar
		

# Modo de Batalha (Desaparece e perde movimento/colisão)
func stop_dodging() -> void:
	visible = false
	set_physics_process(false)
	if collision_shape:
		collision_shape.set_deferred("disabled", true) # Jeito seguro de desativar
# MOVIMENTAÇÃO
func _physics_process(_delta: float) -> void:
	var input_vector := Input.get_vector("Left", "Right", "Up", "Down")
	
	if input_vector != Vector2.ZERO:
		velocity = input_vector * SPEED
	else:
		velocity = velocity.move_toward(Vector2.ZERO, SPEED)
		
	move_and_slide()
