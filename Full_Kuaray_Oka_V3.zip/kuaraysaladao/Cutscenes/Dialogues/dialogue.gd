extends Control

# ==============================================================================
# 1. REFERÊNCIAS AOS NÓS DA CENA
# ==============================================================================
@onready var k_slot: TextureRect = $K_Slot
@onready var interlocutor_slot: TextureRect = $Interlocutor_Slot
@onready var sprite_caixa: Sprite2D = $DialogueBox_Sprite
@onready var name_label: Label = $Name_Dialogue
@onready var text_label: RichTextLabel = $Text_Dialogue

# ==============================================================================
# 2. CONFIGURAÇÕES E VARIÁVEIS VISUAIS
# ==============================================================================
@export var velocidade_letra: float = 0.035 

const COR_ATIVO = Color(1.0, 1.0, 1.0, 1.0)          # Cor normal (brilhante)
const COR_INATIVO = Color(0.35, 0.35, 0.45, 1.0)     # Escurecido (sombreado)
const ESCALA_ATIVA = Vector2(1.05, 1.05)             # Leve zoom no personagem ativo
const ESCALA_INATIVA = Vector2(0.95, 0.95)           # Ligeiramente menor quando inativo

var pos_tag_direita: Vector2
var pos_tag_esquerda: Vector2

var roteiro_atual: Array[Dictionary] = []
var indice_fala: int = 0
var digitando: bool = false
var tween_texto: Tween
var tween_visuais: Tween

# ==============================================================================
# 3. PRÉ-CARREGAMENTO DAS EXPRESSÕES
# ==============================================================================
# Expressões do Kuaray
const K_RELATIVE = preload("res://The_Assets/Assets_Real/Kuaray_Oka/K-Oka_Cutscene/Relative_KO.png")
const K_BRUH = preload("res://The_Assets/Assets_Real/Kuaray_Oka/K-Oka_Cutscene/Bruh_KO.png")
const K_DISAPPOINTED = preload("res://The_Assets/Assets_Real/Kuaray_Oka/K-Oka_Cutscene/Disappointed_KO.png")
const K_MOCKED = preload("res://The_Assets/Assets_Real/Kuaray_Oka/K-Oka_Cutscene/Mocked_KO.png")
const K_SERIOUS = preload("res://The_Assets/Assets_Real/Kuaray_Oka/K-Oka_Cutscene/Serious_KO.png")
const K_THINKING = preload("res://The_Assets/Assets_Real/Kuaray_Oka/K-Oka_Cutscene/Thinking_KO.png")
const K_UHH = preload("res://The_Assets/Assets_Real/Kuaray_Oka/K-Oka_Cutscene/Uhh_KO.png")
const K_SHY = preload("res://The_Assets/Assets_Real/Kuaray_Oka/K-Oka_Cutscene/Shy_KO.png")
const K_GUILTY = preload("res://The_Assets/Assets_Real/Kuaray_Oka/K-Oka_Cutscene/Guilty_KO.png")

# Expressões do Enzo
const ENZO_NEUTRAL = preload("res://The_Assets/Assets_Real/Enzo/Enzo_Cutscene/Neutral_Enzo.png")
const ENZO_SUPRISED = preload("res://The_Assets/Assets_Real/Enzo/Enzo_Cutscene/Suprised_Enzo.png")
const ENZO_CRYING_ACC = preload("res://The_Assets/Assets_Real/Enzo/Enzo_Cutscene/CryingAccording_Enzo.png")
const ENZO_SAD_CRYING = preload("res://The_Assets/Assets_Real/Enzo/Enzo_Cutscene/SadCrying_Enzo.png")
const ENZO_REFLEXIVE = preload("res://The_Assets/Assets_Real/Enzo/Enzo_Cutscene/Reflexive_enzo.png")

# Expressões da Viviane
const VIVIANE_CRYING_TALKING = preload("res://The_Assets/Assets_Real/Viviane/Viviane_Cutscene/Crying_Talking_Viviane.png")
const VIVIANE_CRYING = preload("res://The_Assets/Assets_Real/Viviane/Viviane_Cutscene/Crying_Viviane.png")
const VIVIANE_HAPPY_TALKING = preload("res://The_Assets/Assets_Real/Viviane/Viviane_Cutscene/Happy_Talking_Viviane.png")
const VIVIANE_HAPPY = preload("res://The_Assets/Assets_Real/Viviane/Viviane_Cutscene/Happy_Viviane.png")
const VIVIANE_NEUTRAL_TALKING = preload("res://The_Assets/Assets_Real/Viviane/Viviane_Cutscene/Neutral_Talking_Viviane.png")
const VIVIANE_NEUTRAL = preload("res://The_Assets/Assets_Real/Viviane/Viviane_Cutscene/Neutral_Viviane.png")
const VIVIANE_SAD = preload("res://The_Assets/Assets_Real/Viviane/Viviane_Cutscene/Sad_Viviane.png")
const VIVIANE_SMILING = preload("res://The_Assets/Assets_Real/Viviane/Viviane_Cutscene/Smiling_Viviane.png")

# ==============================================================================
# 4. ROTEIROS DAS CUTSCENES
# ==============================================================================

# --- ROTEIRO ENZO ---
var roteiro_enzo: Array[Dictionary] = [
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_RELATIVE,
		"img_interlocutor": ENZO_NEUTRAL,
		"texto": "Bem vindo, como posso ajudar?"
	},
	{
		"nome": "",
		"lado": "esquerda",
		"img_k": K_UHH,
		"texto": "[i]*Há um silêncio constrangedor. Kuaray olha para o adolescente confuso.*[/i]"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_BRUH,
		"texto": "O que você quer?"
	},
	{
		"nome": "Enzo",
		"lado": "direita",
		"img_interlocutor": ENZO_SUPRISED,
		"texto": "E-eu..."
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_MOCKED,
		"texto": "Fala. [i](fala com arrogância)[/i]"
	},
	{
		"nome": "Enzo",
		"lado": "direita",
		"img_interlocutor": ENZO_CRYING_ACC,
		"texto": "[i]*(Olha assustado sem conseguir responder)*[/i]"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_THINKING,
		"texto": "Ansiedade?"
	},
	{
		"nome": "Enzo",
		"lado": "direita",
		"img_interlocutor": ENZO_SAD_CRYING,
		"texto": "[i]*(Acena concordando com a cabeça)*[/i]"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_DISAPPOINTED,
		"texto": "(suspiro) Ok, senta e relaxa, eu resolvo."
	},
	{
		"nome": "",
		"lado": "esquerda",
		"texto": "[i]*Kuaray acende os incensos no ambiente...*[/i]"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_SERIOUS,
		"texto": "Você já deve saber como funciona, né? Basicamente eu vou 'entrar' na sua cabeça e destruir o seu problema."
	},
	{
		"nome": "Enzo",
		"lado": "direita",
		"img_interlocutor": ENZO_REFLEXIVE,
		"texto": "Isso não é meio..? Err-"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_SHY,
		"texto": "Tá, vamos começar."
	},
	{
		"nome": "",
		"lado": "esquerda",
		"texto": "[i]*Início do ritual...*[/i]"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_SERIOUS,
		"texto": "[color=sandybrown][i]Naturaleza ohenduka peteĩ ñe’ẽ, ha ahendu.\n\nOh, Mbyja Guasu, eme’ẽ chéve ne mbarete aike haĝua ko ángape ha amopotĩ haĝua, ha emyenyhẽ haĝua nde brillantez-gui.[/i][/color]"
	}
]

# --- ROTEIRO VIVIANE - DIÁLOGO I (Antes do Ritual) ---
var roteiro_viviane_1: Array[Dictionary] = [
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_RELATIVE,
		"img_interlocutor": VIVIANE_NEUTRAL,
		"texto": "Bem vinda, como posso ajudar?"
	},
	{
		"nome": "Viviane",
		"lado": "direita",
		"img_interlocutor": VIVIANE_NEUTRAL_TALKING,
		"texto": "Você não tem cara de Pajé. [i](desconfiada)[/i]"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_MOCKED,
		"texto": "E você por acaso já viu algum outro pajé?"
	},
	{
		"nome": "Viviane",
		"lado": "direita",
		"img_interlocutor": VIVIANE_NEUTRAL,
		"texto": "…"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_BRUH,
		"texto": "Foi o que eu pensei."
	},
	{
		"nome": "Viviane",
		"lado": "direita",
		"img_interlocutor": VIVIANE_NEUTRAL_TALKING,
		"texto": "Enfim, você conseguiria me ajudar com o meu problema?"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_RELATIVE,
		"texto": "Se você pagar, sim."
	},
	{
		"nome": "Viviane",
		"lado": "direita",
		"img_interlocutor": VIVIANE_SAD,
		"texto": "Quero que você me faça esquecer de uma memória."
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_THINKING,
		"texto": "De que?"
	},
	{
		"nome": "Viviane",
		"lado": "direita",
		"img_interlocutor": VIVIANE_CRYING_TALKING,
		"texto": "[i](hesitante)[/i] …de uma certa pessoa."
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_SERIOUS,
		"texto": "Certeza? Isso pode ser-"
	},
	{
		"nome": "Viviane",
		"lado": "direita",
		"img_interlocutor": VIVIANE_CRYING_TALKING,
		"texto": "SIM!"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_SERIOUS,
		"texto": "… Certo, então vamos começar."
	}
]

# --- ROTEIRO VIVIANE - DIÁLOGO II (Depois do Ritual) ---
var roteiro_viviane_2: Array[Dictionary] = [
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_DISAPPOINTED,
		"img_interlocutor": VIVIANE_NEUTRAL,
		"texto": "Nossa, esse foi um dos piores. [i](enojado)[/i]"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_THINKING,
		"texto": "E aí, como você se sente?"
	},
	{
		"nome": "Viviane",
		"lado": "direita",
		"img_interlocutor": VIVIANE_HAPPY_TALKING,
		"texto": "…Parece que um peso enorme foi tirado de cima de mim. [i](suspira)[/i]"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_RELATIVE,
		"texto": "Que bom."
	},
	{
		"nome": "Viviane",
		"lado": "direita",
		"img_interlocutor": VIVIANE_SMILING,
		"texto": "Nossa, tá quente aqui... [i](começa a tirar a camisa)[/i]"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_SHY,
		"texto": "EI AQUI NÃO! [i](interrompe ela)[/i]"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_BRUH,
		"texto": "... Enfim, sobre o pagamento."
	},
	{
		"nome": "Viviane",
		"lado": "direita",
		"img_interlocutor": VIVIANE_HAPPY_TALKING,
		"texto": "Siiiim! Aqui está. Você é tão gente boa! Por que não vai lá em casa hoje? Eu moro em-"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_GUILTY,
		"texto": "Não! Não precisa me contar."
	},
	{
		"nome": "Viviane",
		"lado": "direita",
		"img_interlocutor": VIVIANE_NEUTRAL,
		"texto": "[i](confusa)[/i] Ok? [i](sai)[/i]"
	},
	{
		"nome": "Kuaray_Oka",
		"lado": "esquerda",
		"img_k": K_DISAPPOINTED,
		"texto": "[i]*suspiro*[/i]"
	}
]

# ==============================================================================
# 5. CICLO DE VIDA E LÓGICA DO DIÁLOGO
# ==============================================================================
func _ready() -> void:
	text_label.bbcode_enabled = true
	
	k_slot.pivot_offset = k_slot.size / 2
	interlocutor_slot.pivot_offset = interlocutor_slot.size / 2

	pos_tag_direita = name_label.position
	var centro_x = sprite_caixa.position.x
	var dist_do_centro = pos_tag_direita.x - centro_x
	pos_tag_esquerda = Vector2(centro_x - dist_do_centro - name_label.size.x, pos_tag_direita.y)

	# --- TESTES DE CUTSCENES ---
	# Basta descomentar a que quiser testar no momento:
	# iniciar_cutscene_enzo()
	iniciar_cutscene_viviane_parte_2()
	# iniciar_cutscene_viviane_parte_2()

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_accept"):
		if digitando:
			_completar_fala_instantaneamente()
		else:
			_proxima_fala()

# --- FUNÇÕES PÚBLICAS PARA CHAMAR AS CUTSCENES NO SEU JOGO ---
func iniciar_cutscene_enzo() -> void:
	iniciar_dialogo(roteiro_enzo)

func iniciar_cutscene_viviane_parte_1() -> void:
	iniciar_dialogo(roteiro_viviane_1)

func iniciar_cutscene_viviane_parte_2() -> void:
	iniciar_dialogo(roteiro_viviane_2)

func iniciar_dialogo(roteiro: Array[Dictionary]) -> void:
	roteiro_atual = roteiro
	indice_fala = 0
	visible = true
	_mostrar_fala_atual()

func _mostrar_fala_atual() -> void:
	if indice_fala >= roteiro_atual.size():
		_finalizar_dialogo()
		return
		
	var dados = roteiro_atual[indice_fala]
	
	name_label.text = dados["nome"]
	text_label.text = dados["texto"]
	
	if dados.has("img_k") and dados["img_k"] != null:
		k_slot.texture = dados["img_k"]
		
	if dados.has("img_interlocutor") and dados["img_interlocutor"] != null:
		interlocutor_slot.texture = dados["img_interlocutor"]
		
	_atualizar_lado_e_destaque(dados["lado"])
	
	text_label.visible_ratio = 0.0
	digitando = true
	
	var tempo_total = text_label.get_parsed_text().length() * velocidade_letra
	if tween_texto: tween_texto.kill()
	
	tween_texto = create_tween()
	tween_texto.tween_property(text_label, "visible_ratio", 1.0, tempo_total)
	tween_texto.finished.connect(func(): digitando = false)

func _atualizar_lado_e_destaque(lado_ativo: String) -> void:
	if lado_ativo == "esquerda":
		sprite_caixa.flip_h = false
		name_label.position = pos_tag_direita
	else:
		sprite_caixa.flip_h = true
		name_label.position = pos_tag_esquerda

	if tween_visuais: tween_visuais.kill()
	tween_visuais = create_tween().set_parallel(true)
	
	if lado_ativo == "esquerda":
		tween_visuais.tween_property(k_slot, "modulate", COR_ATIVO, 0.2)
		tween_visuais.tween_property(k_slot, "scale", ESCALA_ATIVA, 0.2)
		tween_visuais.tween_property(interlocutor_slot, "modulate", COR_INATIVO, 0.2)
		tween_visuais.tween_property(interlocutor_slot, "scale", ESCALA_INATIVA, 0.2)
	else:
		tween_visuais.tween_property(interlocutor_slot, "modulate", COR_ATIVO, 0.2)
		tween_visuais.tween_property(interlocutor_slot, "scale", ESCALA_ATIVA, 0.2)
		tween_visuais.tween_property(k_slot, "modulate", COR_INATIVO, 0.2)
		tween_visuais.tween_property(k_slot, "scale", ESCALA_INATIVA, 0.2)

func _completar_fala_instantaneamente() -> void:
	if tween_texto: tween_texto.kill()
	text_label.visible_ratio = 1.0
	digitando = false

func _proxima_fala() -> void:
	indice_fala += 1
	_mostrar_fala_atual()

func _finalizar_dialogo() -> void:
	visible = false
	print("Fim do diálogo!")
