extends CharacterBody2D

const SPEED: float = 200


func _physics_process(_delta: float) -> void:
	var input_direction := Input.get_vector("esquerda", "direita", "cima", "baixo")

	velocity = input_direction * SPEED
	move_and_slide()
