extends Area2D

@onready var aviso = $Slap_Warning_Red
@onready var sprite_tapa = $Slap_Sprite
@onready var hitbox = $Slap_Hitbox

var tempo_de_aviso: float = 0.8 
var escala_original_sprite: Vector2 

# TRAVA DE SEGURANÇA: Só fica verdadeira quando a mão bate no chão
var pode_dar_dano: bool = false 

func _ready() -> void:
	escala_original_sprite = sprite_tapa.scale
	sprite_tapa.visible = false
	
	# Usar set_deferred é mais seguro para alterar físicas no _ready
	hitbox.set_deferred("disabled", true) 
	aviso.visible = true
	
	body_entered.connect(_on_body_entered)
	_dar_o_tapa()

func _dar_o_tapa() -> void:
	await get_tree().create_timer(tempo_de_aviso).timeout
	
	aviso.visible = false
	sprite_tapa.visible = true
	sprite_tapa.scale = escala_original_sprite * 3.0 
	
	var tween = create_tween().set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	tween.tween_property(sprite_tapa, "scale", escala_original_sprite, 0.2)
	
	await tween.finished
	
	# ATIVA A COLISÃO E ABRE A TRAVA DE DANO!
	hitbox.set_deferred("disabled", false)
	pode_dar_dano = true
	
	await get_tree().create_timer(0.5).timeout
	queue_free()

func _on_body_entered(body: Node2D) -> void:
	if not pode_dar_dano:
		return
		
	if body.is_in_group("Player") and body.has_method("tomar_dano"):
		print("⚠️ DANO CAUSADO POR: ", self.name, " | TEMPO DE JOGO: ", Time.get_ticks_msec(), "ms")
		body.tomar_dano(10)
