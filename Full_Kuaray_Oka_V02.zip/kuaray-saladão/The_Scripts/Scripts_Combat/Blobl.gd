extends CharacterBody2D

const Tapa_Cena = preload("res://The_Scenes/Scenes_Combat/Blobl/slap.tscn")
const Lambida_Cena = preload("res://The_Scenes/Scenes_Combat/Blobl/Lick.tscn")

func iniciar_ataque() -> void:
	# Sorteia um número: 0 ou 1
	var escolha = randi() % 2
	
	if escolha == 0:
		_sequencia_de_tapas()
	else:
		_sequencia_de_lambidas()

# --- SISTEMA DE TAPAS ---
func _sequencia_de_tapas() -> void:
	var player = get_tree().get_first_node_in_group("Player")
	
	# Sorteia entre 15 e 25 tapas
	var quantidade_tapas = randi_range(15, 25)
	
	for i in range(quantidade_tapas):
		if player:
			_invocar_maozada(player.global_position)
		else:
			_invocar_maozada(Vector2(576, 380))
			
		# Tempo reduzido para 0.4s para criar o efeito de "trilha" perseguindo o player
		await get_tree().create_timer(0.4).timeout

func _invocar_maozada(posicao_alvo: Vector2) -> void:
	var novo_tapa = Tapa_Cena.instantiate()
	novo_tapa.global_position = posicao_alvo
	get_tree().current_scene.add_child(novo_tapa)
	
# --- SISTEMA DE LAMBIDAS ---
func _sequencia_de_lambidas() -> void:
	# Sorteia entre 5 e 7 rodadas de ataques (ondas)
	var ondas_de_ataque = randi_range(5, 7)
	
	for i in range(ondas_de_ataque):
		# Sorteia se nesta onda virão 1 ou 2 lambidas ao mesmo tempo
		var quantidade_simultanea = randi_range(1, 2)
		
		for j in range(quantidade_simultanea):
			_invocar_lambida_aleatoria()
			
		# Tempo de respiro antes da próxima onda de bocas aparecer
		await get_tree().create_timer(1.2).timeout 

func _invocar_lambida_aleatoria() -> void:
	var nova_lambida = Lambida_Cena.instantiate()
	
	var centro_caixa = Vector2(576, 380)
	var angulo_aleatorio = randf_range(0, TAU)
	var distancia = 250.0 
	
	var pos_spawn = centro_caixa + Vector2(cos(angulo_aleatorio), sin(angulo_aleatorio)) * distancia
	nova_lambida.global_position = pos_spawn
	
	var alvo_aleatorio = centro_caixa + Vector2(randf_range(-80, 80), randf_range(-80, 80))
	nova_lambida.rotation = (alvo_aleatorio - pos_spawn).angle() - PI/2
	
	get_tree().current_scene.add_child(nova_lambida)
