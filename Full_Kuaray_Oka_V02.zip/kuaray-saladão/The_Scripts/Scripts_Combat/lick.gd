extends Area2D

@onready var animacao = $Lick_Animation

func _ready() -> void:
	# Conecta o sinal de colisão
	body_entered.connect(_on_body_entered)
	
	# REDUZ A VELOCIDADE DA ANIMAÇÃO PELA METADE (0.5x)
	# Se quiser ainda mais lenta, coloque 0.3 ou 0.4.
	animacao.speed_scale = 0.5 
	
	# Toca a animação
	animacao.play("Lick")
	
	# O await vai respeitar a nova velocidade automaticamente!
	await animacao.animation_finished
	
	queue_free()

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player") and body.has_method("tomar_dano"):
		body.tomar_dano(10)
