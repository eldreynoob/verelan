extends CharacterBody2D

const SPEED = 200.0
@export var is_dodging = false

# Variáveis do sistema de vida
var vida: int = 50
var invencivel: bool = false

# Referências dos nós do Kuaray
@onready var animation_player: AnimationPlayer = $Kuaray_Animation
@onready var collision_shape: CollisionShape2D = $Kuaray_HitBox
@onready var sprite: Sprite2D = $Kuaray_Sprite 

func _ready() -> void:
	is_dodging = false
	if animation_player and animation_player.has_animation("Shine"):
		animation_player.play("Shine")
	stop_dodging()

func _physics_process(_delta: float) -> void:
	var input_vector := Input.get_vector("Left", "Right", "Up", "Down")
	
	if input_vector != Vector2.ZERO:
		velocity = input_vector * SPEED
	else:
		velocity = Vector2.ZERO
		
	move_and_slide()

# --- SISTEMA DE COMBATE (ENTRAR/SAIR) ---

func start_dodging() -> void:
	is_dodging = true
	visible = true
	set_physics_process(true)
	if collision_shape:
		collision_shape.set_deferred("disabled", false)

func stop_dodging() -> void:
	is_dodging = false
	visible = false
	set_physics_process(false)
	if collision_shape:
		collision_shape.set_deferred("disabled", true)

# --- SISTEMA DE VIDA E DANO ---

func tomar_dano(dano: int) -> void:
	if invencivel:
		return
		
	vida -= dano
	print("Tomou dano! Vida restante: ", vida) # ADICIONE ESTA LINHA
	
	var barra = get_tree().get_first_node_in_group("BarraDeVida")
	if barra:
		barra.value = vida
	else:
		print("ERRO: Barra de vida não encontrada!") # ADICIONE ESTA LINHA
		
	if vida <= 0:
		morrer()
	else:
		ativar_iframes()

func ativar_iframes() -> void:
	invencivel = true
	
	# Faz o Kuaray piscar indicando que tomou dano
	var tween = create_tween().set_loops(5)
	tween.tween_property(sprite, "modulate:a", 0.2, 0.1) 
	tween.tween_property(sprite, "modulate:a", 1.0, 0.1) 
	
	# Tempo que o player fica imune a novos golpes
	await get_tree().create_timer(1.0).timeout 
	
	invencivel = false
	# Garante que a imagem fique 100% visível quando a imunidade acabar
	sprite.modulate.a = 1.0 

func morrer() -> void:
	# Quando o HP zera
	print("Game Over! Kuaray Morreu.")
	queue_free()
