extends Button

@export var is_dodging = false

func _ready() -> void:
	is_dodging = false

func _on_pressed() -> void:
	# 1. Puxa as referências dos grupos
	var Kuaray = get_tree().get_first_node_in_group("Player")
	var battle_box = get_tree().get_first_node_in_group("BattleBox")
	var labubu = get_tree().get_first_node_in_group("Enemies") 
	
	# 2. Lógica de teleporte e estado
	if is_dodging == false:
		Kuaray.position = Vector2(576, 380)
		is_dodging = true
		
	# 3. Chama o jogador
	if Kuaray and Kuaray.has_method("start_dodging"):
		Kuaray.start_dodging()
		
	# 4. Chama a animação da caixa
	if battle_box and battle_box.has_method("virar_quadrado"):
		battle_box.virar_quadrado()
		
	# 5. Lógica inteligente para iniciar o ataque do Labubu
	if labubu == null:
		print("ERRO: Nenhum inimigo no grupo 'Enemies' foi encontrado!")
	else:
		# Verifica se o script está direto no nó que tem o grupo
		if labubu.has_method("iniciar_ataque"):
			labubu.iniciar_ataque()
			print("SUCESSO: Labubu atirou (Script no próprio nó)")
		else:
			# Se não estiver, procura no nó filho chamado "Enemy_Display"
			var display = labubu.get_node_or_null("Enemy_Display")
			if display and display.has_method("iniciar_ataque"):
				display.iniciar_ataque()
				print("SUCESSO: Labubu atirou (Script no nó filho Enemy_Display)")
			else:
				print("ERRO: O script do Labubu não foi encontrado nem no nó pai nem no filho!")
