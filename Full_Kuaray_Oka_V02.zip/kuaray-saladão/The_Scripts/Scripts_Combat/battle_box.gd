extends Panel

# Referências atualizadas para a sua estrutura exata
@onready var top_wall: CollisionShape2D = $CollideBox/Up
@onready var bottom_wall: CollisionShape2D = $CollideBox/Down
@onready var left_wall: CollisionShape2D = $CollideBox/Left
@onready var right_wall: CollisionShape2D = $CollideBox/Right

# Variáveis para guardar as posições originais e alvo
var menu_size: Vector2
var menu_pos: Vector2
var combat_size: Vector2
var combat_pos: Vector2

const WALL_THICKNESS: float = 20.0

func _ready() -> void:
	# 1. Salva o tamanho retangular inicial
	menu_size = size
	menu_pos = position
	
	# 2. Calcula o quadrado (A largura se torna igual à altura)
	combat_size = Vector2(size.y, size.y)
	
	# 3. Calcula a posição para o quadrado ficar centralizado
	combat_pos = Vector2(position.x + (size.x - combat_size.x) / 2.0, position.y)
	
	# 4. Força a colisão a se atualizar sozinha sempre que o tamanho mudar
	resized.connect(_update_collisions)
	_update_collisions()

# Anima a caixa encolhendo para o meio
func virar_quadrado() -> void:
	var tween = create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween.set_parallel(true) # Faz tamanho e posição animarem juntos
	tween.tween_property(self, "size", combat_size, 0.4)
	tween.tween_property(self, "position", combat_pos, 0.4)

# Anima a caixa voltando a esticar
func virar_retangulo() -> void:
	var tween = create_tween().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween.set_parallel(true)
	tween.tween_property(self, "size", menu_size, 0.4)
	tween.tween_property(self, "position", menu_pos, 0.4)

# Mantém as paredes sempre nas bordas da caixa
# Mantém as paredes sempre nas bordas internas da caixa
func _update_collisions() -> void:
	if not top_wall or not top_wall.shape: return
	
	var box_size = size
	
	# Ajuste este valor para a espessura da borda branca do seu StyleBox
	const BORDER_THICKNESS: float = 10.0 
	
	(top_wall.shape as RectangleShape2D).size = Vector2(box_size.x, WALL_THICKNESS)
	# Desce a parede do topo para dentro
	top_wall.position = Vector2(box_size.x / 2.0, BORDER_THICKNESS - (WALL_THICKNESS / 2.0))
	
	(bottom_wall.shape as RectangleShape2D).size = Vector2(box_size.x, WALL_THICKNESS)
	# Sobe a parede de baixo para dentro
	bottom_wall.position = Vector2(box_size.x / 2.0, box_size.y - BORDER_THICKNESS + (WALL_THICKNESS / 2.0))
	
	(left_wall.shape as RectangleShape2D).size = Vector2(WALL_THICKNESS, box_size.y)
	# Puxa a parede da esquerda para a direita
	left_wall.position = Vector2(BORDER_THICKNESS - (WALL_THICKNESS / 2.0), box_size.y / 2.0)
	
	(right_wall.shape as RectangleShape2D).size = Vector2(WALL_THICKNESS, box_size.y)
	# Empurra a parede da direita para a esquerda
	right_wall.position = Vector2(box_size.x - BORDER_THICKNESS + (WALL_THICKNESS / 2.0), box_size.y / 2.0)
