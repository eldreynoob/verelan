extends Node2D # Ou Sprite2D, dependendo do tipo do seu nó Enemy_Display

@onready var bola: Area2D = $Bola

# Guarda a posição original da bola (a mão do Labubu)
@onready var posicao_mao: Vector2 = bola.position 

var direcao_ataque: Vector2 = Vector2.ZERO
var velocidade_bola: float = 1000.0 # Ajuste a velocidade aqui
var atacando: bool = false

func _ready() -> void:
	# Conecta a bola via código para detectar quando ela bate em alguma parede
	bola.body_entered.connect(_quando_a_bola_bater)

func _physics_process(delta: float) -> void:
	if atacando:
		# Move a bola constantemente na direção escolhida
		bola.position += direcao_ataque * velocidade_bola * delta

# Função chamada pelo botão FIGHT
func iniciar_ataque() -> void:
	atacando = true
	_atirar_bola()

# Função para cancelar o ataque depois (quando for o turno do menu)
func parar_ataque() -> void:
	atacando = false
	bola.position = posicao_mao

# Lógica de respawn e escolha de direção
func _atirar_bola() -> void:
	bola.position = posicao_mao # Volta pra mão do Labubu
	
	# Direções possíveis: Para baixo, Diagonal Esquerda, Diagonal Direita
	var direcoes = [
		Vector2(0, 1), 
		Vector2(-0.8, 1).normalized(),
		Vector2(0.8, 1).normalized()
	]
	
	# Escolhe uma das direções da lista aleatoriamente
	direcao_ataque = direcoes.pick_random()

# Roda automaticamente quando a Área2D da Bola encosta em algum Corpo Físico
func _quando_a_bola_bater(body: Node2D) -> void:
	if not atacando: return
	
	# 1. Se a bola bater na caixa do jogador, ela atravessa e ignora
	if body.name == "CollideBox":
		return
		
	# 2. Se bater em QUALQUER OUTRA parede (seus nós UP, DOWN, LEFT, RIGHT), ela reseta!
	if body is StaticBody2D:
		_atirar_bola()
		
	# DICA PARA O FUTURO (Quando for dar dano no Kuaray): 
	# elif body.is_in_group("Player"):
	#     print("Tomou dano!")
	#     _atirar_bola() # Desespawna a bola após acertar o player
