extends Area2D

@export var titulo: String = "Memória"
@export_multiline var descricao: String = "Um lugar perfeito, congelado dentro de uma fotografia. Talvez não fosse assim na realidade… mas, dentro de uma memória, ninguém precisa ver as imperfeições."
@export var icone: Texture2D

var player_no_alcance: Node2D = null

func _on_body_entered(body: Node2D) -> void:
	if body.name == "Kuaray" or body.is_in_group("player"):
		player_no_alcance = body
		if body.has_method("exibir_dica_interacao"):
			body.exibir_dica_interacao()

func _on_body_exited(body: Node2D) -> void:
	if body == player_no_alcance:
		if body.has_method("esconder_dica_interacao"):
			body.esconder_dica_interacao()
		player_no_alcance = null

func _process(_delta: float) -> void:
	if player_no_alcance and Input.is_action_just_pressed("interagir"):
		coletar_item()

func coletar_item() -> void:
	if player_no_alcance:
		# Envia os dados para a UI do player e abre o painel
		if player_no_alcance.has_method("exibir_painel_item"):
			player_no_alcance.exibir_painel_item(titulo, descricao, icone)
		if player_no_alcance.has_method("esconder_dica_interacao"):
			player_no_alcance.esconder_dica_interacao()
	
	# Desativa a colisão imediatamente e apaga o item
	$CollisionShape2D.set_deferred("disabled", true)
	queue_free()
