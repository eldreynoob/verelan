extends CharacterBody2D

const SPEED = 200.0
@export var is_dodging = false
var vida: int = 100
var is_invincible: bool = false

@onready var animation_player: AnimationPlayer = $Kuaray_Animation
@onready var collision_shape: CollisionShape2D = $Kuaray_HitBox

func _ready() -> void:
	is_dodging = false
	if animation_player and animation_player.has_animation("Shine"):
		animation_player.play("Shine")
	stop_dodging()

func _physics_process(_delta: float) -> void:
	var input_vector := Input.get_vector("Left", "Right", "Up", "Down")
	
	if input_vector != Vector2.ZERO:
		velocity = input_vector * SPEED
	else:
		velocity = Vector2.ZERO
		
	move_and_slide()

func start_dodging() -> void:
	is_dodging = true
	visible = true
	set_physics_process(true)
	if collision_shape:
		collision_shape.set_deferred("disabled", false)


func stop_dodging() -> void:
	is_dodging = false
	visible = false
	set_physics_process(false)
	if collision_shape:
		collision_shape.set_deferred("disabled", true)

func tomar_dano(dano: int) -> void:
	if is_invincible:
		return
		
	vida -= dano
	
	if vida <= 0:
		morrer()
	else:
		i_frame(1.0)


func i_frame(duracao: float) -> void:
	is_invincible = true
	
	var tween = create_tween()
	var ciclos = int(duracao / 0.2)

	for i in range(ciclos):
		tween.tween_property(self, "modulate:a", 0.2, 0.1)
		tween.tween_property(self, "modulate:a", 1.0, 0.1)

	await tween.finished
	
	self.modulate.a = 1.0
	is_invincible = false


func morrer() -> void:
	queue_free()
