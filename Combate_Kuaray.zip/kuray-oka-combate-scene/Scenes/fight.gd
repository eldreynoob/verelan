extends Button
@export var Kuaray: Node

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_pressed() -> void:
	if Kuaray and Kuaray.has_method("start_dodging"):
		Kuaray.start_dodging()
