extends CharacterBody2D
#Constantes
const SPEED = 500.0
#Variáveis
@onready var animation_player: AnimationPlayer = $Kuaray_Animation

func _ready() -> void: #Tudo que deve SER.. assim que a cena carrega
	animation_player.play("Shine") #Animação de brilho ("Shine")
	visible = false #Desabilita a visibilidade do Kuaray no inicio do modo de batalha
	process_mode = PROCESS_MODE_DISABLED # Desativa a movimentação e colisão no inicio do modo de batalha
#FUNÇÕES 

#Modo de desvio
func start_dodging() -> void:
	visible = true # Habilita a visibilidade do Kuaray pro modo de desvio
	process_mode = PROCESS_MODE_INHERIT # Ativa a movimentação e colisão

#Modo de Batalha
func stop_dodging() -> void:
	visible = false # Desabilita a visibilidade do Kuaray pro modo de batalha
	process_mode = PROCESS_MODE_DISABLED # Desativa a movimentação e colisão 
	
	
	
#MOVIMENTAÇÃO
func _physics_process(_delta: float) -> void:
	var input_vector := Input.get_vector("Left", "Right", "Up", "Down")
	
	if input_vector != Vector2.ZERO:
		velocity = input_vector * SPEED
	else:
		velocity = velocity.move_toward(Vector2.ZERO, SPEED)
		
	move_and_slide()
	
func _process(_delta: float) -> void:
	start_dodging()
	
